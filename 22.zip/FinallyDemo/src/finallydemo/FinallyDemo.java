/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finallydemo;
import java.io.*;
/**
 *
 * @author cclab
 */
public class FinallyDemo {
    static void funcA() throws FileNotFoundException
    {
        try{
            System.out.println("Inside funcA()");
            throw new FileNotFoundException();
        }
        finally{
            System.out.println("inside finally of funcA()");
        }
    }
    static void funcB(){
        try{
        System.out.println("Inside funcB()");
    
    }
         finally{
            System.out.println("inside finally of funcB()");
        }
    }
    static void funcc(){
        try{
        System.out.println("Inside funcC()");
    
    }
         finally{
            System.out.println("inside finally of funcC()");
        }
    }

    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
