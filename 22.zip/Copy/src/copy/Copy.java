/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package copy;

import java.util.Scanner;

/**
 *
 * @author cclab
 */
public class Copy {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc=new Scanner(System.in);
        String s1=sc.nextLine();
        //int n=sc.nextInt();
        String res=s1.substring(0,2);
        String d="";
        for(int i=0;i<s1.length();i++){
            d+=res;
      
        }
        System.out.println(d);
        
    }
    
}
