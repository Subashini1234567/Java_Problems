/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lower;

import java.util.Scanner;

/**
 *
 * @author cclab
 */
public class Lower {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s1=sc.nextLine();
        String s2=sc.nextLine();
        String res=s1;
       // String a="";
        String b="";
        res=s1.toLowerCase();
        b=s2.toLowerCase();
       
        if(b.charAt(0)==res.charAt(res.length()-1)){
            res+=(b.substring(1));
        }
        else{
            res+=(" ");
            res+=(b);
        }
        System.out.println(res);
     
        //System.out.println(low);
        // TODO code application logic here
    }
    
}
