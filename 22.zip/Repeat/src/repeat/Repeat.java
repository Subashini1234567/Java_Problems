/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repeat;

import java.util.Scanner;

/**
 *
 * @author cclab
 */
public class Repeat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s1=sc.nextLine();
        String s2=sc.nextLine();
        System.out.println(s1+s2+s1);
        //String s3=sc.nextLint();
        
        // TODO code application logic here
    }
    
}
