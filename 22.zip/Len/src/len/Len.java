/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package len;

import java.util.Scanner;

/**
 *
 * @author cclab
 */
public class Len {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String str=sc.nextLine();
        int len=str.length();
        if(len%2==0){
            System.out.println(str.substring(0,len/2));
        }
        else{
            System.out.println("Null");
        }
        
        // TODO code application logic here
    }
    
}
