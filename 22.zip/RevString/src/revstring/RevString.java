/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revstring;

/**
 *
 * @author cclab
 */
public class RevString {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        String str="madam";
        String rev="";
      for(int i=str.length()-1;i>=0;i--){
          rev+=str.charAt(i);
      }
      System.out.println(rev);
      if(str.equals(rev)){
          System.out.println("Palin");
      }
      else{
          System.out.println("Not Palin");
      }
        
        // TODO code application logic here
    }
    
}
