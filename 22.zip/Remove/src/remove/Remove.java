/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package remove;
import java.util.*;
/**
 *
 * @author cclab
 */
public class Remove {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s1=sc.nextLine();
        int l=s1.length();
        if(l>2){
            System.out.println(s1.substring(1,l-1));
        }
        else{
            System.out.println("Invalid");
        }
        
        // TODO code application logic here
    }
    
}
